import 'package:flutter/material.dart';

class AskAnyQuestion extends StatefulWidget {
  @override
  _AskAnyQuestionState createState() => _AskAnyQuestionState();
}

class _AskAnyQuestionState extends State<AskAnyQuestion> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        
      ),
    );
  }
}