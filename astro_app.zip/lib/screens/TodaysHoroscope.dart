import 'package:flutter/material.dart';

class TodaysHoroscope extends StatefulWidget {
  @override
  _TodaysHoroscopeState createState() => _TodaysHoroscopeState();
}

class _TodaysHoroscopeState extends State<TodaysHoroscope> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        
      ),
    );
  }
}