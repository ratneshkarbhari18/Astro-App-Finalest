import 'package:shared_preferences/shared_preferences.dart';

class Constants {
  var prefs = SharedPreferences.getInstance();
  static const apiUrl = "http://3.6.86.32/astro_app_backend/";
}