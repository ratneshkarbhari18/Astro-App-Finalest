package tech.codesevaco.astro_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
